import 'package:cloud_firestore/cloud_firestore.dart';
import 'enums.dart';

class MatchModel {
  final String id;
  final String homeTeamFull;
  final String awayTeamFull;
  final String homeTeamAbbr;
  final String awayTeamAbbr;
  final DateTime matchDate;
  final String venue;
  final MatchStatus status;
  final DateTime? startTime;
  final DateTime? expiresAt;
  final int gameDurationMinutes;

  MatchModel({
    required this.id,
    required this.homeTeamFull,
    required this.awayTeamFull,
    required this.homeTeamAbbr,
    required this.awayTeamAbbr,
    required this.matchDate,
    required this.venue,
    required this.status,
    required this.gameDurationMinutes,
    this.startTime,
    this.expiresAt,
  });

  Map<String, Object?> toMap() {
    return {
      'homeTeamFull': homeTeamFull,
      'awayTeamFull': awayTeamFull,
      'homeTeamAbbr': homeTeamAbbr,
      'awayTeamAbbr': awayTeamAbbr,
      'matchDate': Timestamp.fromDate(matchDate),
      'venue': venue,
      'status': status.name,
      'startTime': startTime == null ? null : Timestamp.fromDate(startTime!),
      'expiresAt': expiresAt == null ? null : Timestamp.fromDate(expiresAt!),
      'gameDurationMinutes': gameDurationMinutes,
      'createdAt': FieldValue.serverTimestamp(),
    };
  }

  static MatchModel fromDoc(DocumentSnapshot<Map<String, dynamic>> doc) {
    final d = doc.data()!;
    return MatchModel(
      id: doc.id,
      homeTeamFull: d['homeTeamFull'] as String,
      awayTeamFull: d['awayTeamFull'] as String,
      homeTeamAbbr: d['homeTeamAbbr'] as String,
      awayTeamAbbr: d['awayTeamAbbr'] as String,
      matchDate: (d['matchDate'] as Timestamp).toDate(),
      venue: d['venue'] as String,
      status: MatchStatus.values.firstWhere((e) => e.name == (d['status'] as String)),
      startTime: d['startTime'] == null ? null : (d['startTime'] as Timestamp).toDate(),
      expiresAt: d['expiresAt'] == null ? null : (d['expiresAt'] as Timestamp).toDate(),
      gameDurationMinutes: (d['gameDurationMinutes'] as num).toInt(),
    );
  }
}

import 'package:cloud_firestore/cloud_firestore.dart';

enum UserRole { user, superadmin }

class UserProfile {
  final String uid;
  final String email;
  final UserRole role;
  final DateTime createdAt;

  const UserProfile({
    required this.uid,
    required this.email,
    required this.role,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
        'uid': uid,
        'email': email,
        'role': role.name,
        'createdAt': Timestamp.fromDate(createdAt),
      };

  static UserProfile fromDoc(DocumentSnapshot<Map<String, dynamic>> doc) {
    final d = doc.data() ?? {};
    final roleStr = (d['role'] ?? 'user').toString();
    final role = UserRole.values.firstWhere(
      (r) => r.name == roleStr,
      orElse: () => UserRole.user,
    );
    final ts = d['createdAt'];
    return UserProfile(
      uid: d['uid']?.toString() ?? doc.id,
      email: d['email']?.toString() ?? '',
      role: role,
      createdAt: ts is Timestamp ? ts.toDate() : DateTime.now(),
    );
  }
}

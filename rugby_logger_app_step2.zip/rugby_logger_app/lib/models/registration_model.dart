import 'package:cloud_firestore/cloud_firestore.dart';

enum MatchSection { scrum, lineout, tackles, discipline, possession }

class RegistrationModel {
  final String userId;
  final List<MatchSection> sections;
  final DateTime expiresAt;
  final bool active;
  final String? purchaseToken;

  const RegistrationModel({
    required this.userId,
    required this.sections,
    required this.expiresAt,
    required this.active,
    this.purchaseToken,
  });

  bool has(MatchSection s) => sections.contains(s);

  Map<String, dynamic> toMap() => {
        'userId': userId,
        'sections': sections.map((e) => e.name).toList(),
        'expiresAt': Timestamp.fromDate(expiresAt),
        'active': active,
        if (purchaseToken != null) 'purchaseToken': purchaseToken,
        'updatedAt': FieldValue.serverTimestamp(),
      };

  static RegistrationModel fromDoc(DocumentSnapshot<Map<String, dynamic>> doc) {
    final d = doc.data() ?? {};
    final raw = (d['sections'] as List?)?.map((e) => e.toString()).toList() ?? <String>[];
    final sections = raw
        .map(
          (s) => MatchSection.values.firstWhere(
            (v) => v.name == s,
            orElse: () => MatchSection.scrum,
          ),
        )
        .toList();
    final ts = d['expiresAt'];
    return RegistrationModel(
      userId: d['userId']?.toString() ?? doc.id,
      sections: sections.toSet().toList(),
      expiresAt: ts is Timestamp ? ts.toDate() : DateTime.now(),
      active: (d['active'] ?? true) == true,
      purchaseToken: d['purchaseToken']?.toString(),
    );
  }
}

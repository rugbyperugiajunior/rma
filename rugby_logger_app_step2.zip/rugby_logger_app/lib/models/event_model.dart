import 'package:cloud_firestore/cloud_firestore.dart';
import 'enums.dart';

class EventModel {
  final String id;
  final EventType type;
  final TeamSide? team;
  final int matchClockSec;
  final Map<String, Object?> payload;
  final DateTime createdAt;

  EventModel({
    required this.id,
    required this.type,
    required this.matchClockSec,
    required this.payload,
    required this.createdAt,
    this.team,
  });

  Map<String, Object?> toMap() {
    return {
      'type': type.name,
      'team': team?.name,
      'matchClockSec': matchClockSec,
      'payload': payload,
      'createdAt': Timestamp.fromDate(createdAt),
    };
  }

  static EventModel fromDoc(DocumentSnapshot<Map<String, dynamic>> doc) {
    final d = doc.data()!;
    return EventModel(
      id: doc.id,
      type: EventType.values.firstWhere((e) => e.name == (d['type'] as String)),
      team: d['team'] == null
          ? null
          : TeamSide.values.firstWhere((e) => e.name == (d['team'] as String)),
      matchClockSec: (d['matchClockSec'] as num).toInt(),
      payload: Map<String, Object?>.from(d['payload'] as Map),
      createdAt: (d['createdAt'] as Timestamp).toDate(),
    );
  }
}

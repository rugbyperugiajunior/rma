enum TeamSide { home, away }

enum MatchStatus { draft, live, ended, expired }

enum EventType { scrum, lineout, tackle, discipline, possession }

enum FieldZone { def22, def50_22, midfield, att50_22, att22 }

extension FieldZoneLabel on FieldZone {
  String get label {
    switch (this) {
      case FieldZone.def22:
        return 'Difesa 22';
      case FieldZone.def50_22:
        return 'Difesa 50-22';
      case FieldZone.midfield:
        return 'Metà campo';
      case FieldZone.att50_22:
        return 'Attacco 50-22';
      case FieldZone.att22:
        return 'Attacco 22';
    }
  }
}

enum TackleResult { good, miss }

enum DisciplineSanction { cp, cl }

enum DisciplineOrigin { play, scrum, lineout }

enum PossessionStartReason {
  scrum,
  lineout,
  recovery,
  penaltyKick,
  freeKick,
  catchFromKick,
}

enum PossessionEndReason {
  scrum,
  lineout,
  turnover,
  penaltyKick,
  freeKick,
  clearanceKick,
}

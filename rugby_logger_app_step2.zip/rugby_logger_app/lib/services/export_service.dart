import 'dart:convert';
import 'dart:io';

import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import '../models/enums.dart';
import '../models/event_model.dart';
import '../models/match_model.dart';
import '../models/registration_model.dart';
import '../models/user_profile.dart';
import 'firestore_service.dart';

class ExportService {
  /// Genera un file unico JSON con le principali TAG delle sezioni.
  /// Ritorna il file generato.
  static Future<File> exportMatchTagsAsJson({required MatchModel match, String? userId}) async {
    final events = await FirestoreService.listAllEvents(match.id);

    // Filter by user's purchased sections (unless superadmin).
    final allowed = <EventType>{...EventType.values};
    if (userId != null) {
      final profSnap = await FirestoreService.usersRef().doc(userId).get();
      final role = profSnap.exists ? UserProfile.fromDoc(profSnap).role : UserRole.user;
      if (role != UserRole.superadmin) {
        final reg = await FirestoreService.getRegistration(matchId: match.id, uid: userId);
        if (reg == null || !reg.active || DateTime.now().isAfter(reg.expiresAt)) {
          allowed
            ..clear();
        } else {
          allowed
            ..clear()
            ..addAll(_eventTypesForSections(reg.sections));
        }
      }
    }

    final scrumTags = <Map<String, Object?>>[];
    final lineoutTags = <Map<String, Object?>>[];
    final tackleTags = <Map<String, Object?>>[];
    final disciplineTags = <Map<String, Object?>>[];
    final possessionTags = <Map<String, Object?>>[];

    for (final e in events) {
      if (!allowed.contains(e.type)) continue;
      switch (e.type) {
        case EventType.scrum:
          scrumTags.add(_pick(e, ['introducedBy', 'wonBy', 'driveBy', 'zone']));
          break;
        case EventType.lineout:
          lineoutTags.add(_pick(e, ['thrownBy', 'wonBy', 'block', 'zone']));
          break;
        case EventType.tackle:
          tackleTags.add(_pick(e, ['team', 'result', 'bucket5m']));
          break;
        case EventType.discipline:
          disciplineTags.add(_pick(e, ['team', 'foulTypeId', 'zone', 'sanction', 'origin']));
          break;
        case EventType.possession:
          possessionTags.add(_pick(e, ['team', 'startReason', 'endReason', 'durationSec']));
          break;
      }
    }

    final doc = {
      'exportVersion': 1,
      'generatedAt': DateTime.now().toIso8601String(),
      'forUserId': userId,
      'match': {
        'id': match.id,
        'homeTeamFull': match.homeTeamFull,
        'awayTeamFull': match.awayTeamFull,
        'homeTeamAbbr': match.homeTeamAbbr,
        'awayTeamAbbr': match.awayTeamAbbr,
        'matchDate': match.matchDate.toIso8601String(),
        'venue': match.venue,
        'status': match.status.name,
        'startTime': match.startTime?.toIso8601String(),
        'expiresAt': match.expiresAt?.toIso8601String(),
        'gameDurationMinutes': match.gameDurationMinutes,
      },
      'tags': {
        'mischia': scrumTags,
        'touche': lineoutTags,
        'placcaggi': tackleTags,
        'disciplina': disciplineTags,
        'possesso': possessionTags,
      }
    };

    final dir = await getApplicationDocumentsDirectory();
    final safeDate = match.matchDate.toIso8601String().split('T').first;
    final filename = 'rugby_match_${match.homeTeamAbbr}_vs_${match.awayTeamAbbr}_$safeDate.json';
    final file = File('${dir.path}/$filename');
    await file.writeAsString(const JsonEncoder.withIndent('  ').convert(doc));
    return file;
  }

  static Set<EventType> _eventTypesForSections(List<MatchSection> sections) {
    final out = <EventType>{};
    for (final s in sections) {
      switch (s) {
        case MatchSection.scrum:
          out.add(EventType.scrum);
          break;
        case MatchSection.lineout:
          out.add(EventType.lineout);
          break;
        case MatchSection.tackles:
          out.add(EventType.tackle);
          break;
        case MatchSection.discipline:
          out.add(EventType.discipline);
          break;
        case MatchSection.possession:
          out.add(EventType.possession);
          break;
      }
    }
    return out;
  }

  static Future<void> shareFile(File file) async {
    await Share.shareXFiles([XFile(file.path)], subject: 'Rugby Logger Export');
  }

  static Map<String, Object?> _pick(EventModel e, List<String> keys) {
    final out = <String, Object?>{};
    // campi comuni utili come tag
    out['type'] = e.type.name;
    out['matchClockSec'] = e.matchClockSec;
    // payload (solo chiavi importanti)
    for (final k in keys) {
      if (k == 'team') {
        // team può stare come campo o dentro payload
        out['team'] = e.team?.name ?? e.payload['team'];
      } else {
        out[k] = e.payload[k];
      }
    }
    return out;
  }
}

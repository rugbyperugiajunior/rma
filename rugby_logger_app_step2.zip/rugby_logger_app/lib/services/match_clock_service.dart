class MatchClockService {
  static int elapsedSecondsSince(DateTime startTime) {
    final now = DateTime.now();
    final diff = now.difference(startTime);
    final sec = diff.inSeconds;
    return sec < 0 ? 0 : sec;
  }

  static String formatClock(int seconds) {
    final m = (seconds ~/ 60).toString().padLeft(2, '0');
    final s = (seconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }
}

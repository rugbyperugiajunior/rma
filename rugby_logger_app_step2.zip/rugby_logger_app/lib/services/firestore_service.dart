import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:uuid/uuid.dart';

import '../models/event_model.dart';
import '../models/match_model.dart';
import '../models/registration_model.dart';
import '../models/user_profile.dart';

class FirestoreService {
  static final _db = FirebaseFirestore.instance;
  static const _uuid = Uuid();

  static CollectionReference<Map<String, dynamic>> matchesRef() => _db.collection('matches');
  static CollectionReference<Map<String, dynamic>> usersRef() => _db.collection('users');

  static Future<void> ensureUserProfile({required String uid, required String email}) async {
    final ref = usersRef().doc(uid);
    final doc = await ref.get();
    if (!doc.exists) {
      final profile = UserProfile(uid: uid, email: email, role: UserRole.user, createdAt: DateTime.now());
      await ref.set(profile.toMap());
    }
  }

  static Stream<DocumentSnapshot<Map<String, dynamic>>> streamUserProfile(String uid) {
    return usersRef().doc(uid).snapshots();
  }

  static Future<String> createMatch(MatchModel match) async {
    final doc = matchesRef().doc();
    await doc.set(match.toMap());
    return doc.id;
  }

  static Stream<QuerySnapshot<Map<String, dynamic>>> streamRecentMatches() {
    return matchesRef().orderBy('createdAt', descending: true).limit(20).snapshots();
  }

  static Future<void> setMatchLive({required String matchId, required DateTime startTime, required DateTime expiresAt}) async {
    await matchesRef().doc(matchId).update({
      'status': 'live',
      'startTime': Timestamp.fromDate(startTime),
      'expiresAt': Timestamp.fromDate(expiresAt),
    });
  }

  static Future<void> endMatch(String matchId) async {
    await matchesRef().doc(matchId).update({
      'status': 'ended',
      'endTime': FieldValue.serverTimestamp(),
    });
  }

  static Future<void> addEvent({required String matchId, required EventModel event}) async {
    final eventsRef = matchesRef().doc(matchId).collection('events');
    final id = event.id.isEmpty ? _uuid.v4() : event.id;
    await eventsRef.doc(id).set(event.toMap());
  }

  // --- Registrations (per match) ---
  static DocumentReference<Map<String, dynamic>> registrationRef({required String matchId, required String uid}) {
    return matchesRef().doc(matchId).collection('registrations').doc(uid);
  }

  static Stream<DocumentSnapshot<Map<String, dynamic>>> streamRegistration({required String matchId, required String uid}) {
    return registrationRef(matchId: matchId, uid: uid).snapshots();
  }

  static Future<void> upsertRegistration({required String matchId, required RegistrationModel registration}) async {
    await registrationRef(matchId: matchId, uid: registration.userId).set(registration.toMap(), SetOptions(merge: true));
  }

  static Future<RegistrationModel?> getRegistration({required String matchId, required String uid}) async {
    final doc = await registrationRef(matchId: matchId, uid: uid).get();
    if (!doc.exists) return null;
    return RegistrationModel.fromDoc(doc);
  }

  static Stream<QuerySnapshot<Map<String, dynamic>>> streamEvents(String matchId) {
    return matchesRef().doc(matchId).collection('events').orderBy('createdAt', descending: true).snapshots();
  }

  static Future<List<EventModel>> listAllEvents(String matchId) async {
    final snap = await matchesRef().doc(matchId).collection('events').orderBy('createdAt').get();
    return snap.docs.map(EventModel.fromDoc).toList();
  }
}

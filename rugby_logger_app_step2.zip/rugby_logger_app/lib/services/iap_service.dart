import 'dart:async';

import 'package:in_app_purchase/in_app_purchase.dart';

/// Thin wrapper around the Flutter `in_app_purchase` plugin.
///
/// NOTE: This project ships with a *working scaffold*.
/// To make purchases actually work you must:
/// - Configure products in Google Play Console / App Store Connect
/// - Set the product IDs below accordingly
/// - Add server-side receipt validation (recommended) in Cloud Functions
class IapService {
  IapService._();

  static final InAppPurchase _iap = InAppPurchase.instance;

  static Stream<List<PurchaseDetails>> purchaseStream() => _iap.purchaseStream;

  static Future<bool> isAvailable() => _iap.isAvailable();

  static Future<ProductDetailsResponse> queryProducts(Set<String> ids) {
    return _iap.queryProductDetails(ids);
  }

  static Future<void> buyConsumable(ProductDetails product) async {
    final param = PurchaseParam(productDetails: product);
    await _iap.buyConsumable(purchaseParam: param);
  }

  static Future<void> completeIfNeeded(PurchaseDetails p) async {
    if (p.pendingCompletePurchase) {
      await _iap.completePurchase(p);
    }
  }

  static Future<void> restore() => _iap.restorePurchases();
}

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../../models/match_model.dart';
import '../../services/firestore_service.dart';
import '../match_dashboard_screen.dart';

/// Minimal superadmin view: can see all matches and open any match dashboard.
///
/// NOTE: The true enforcement must be in Firestore Security Rules.
class SuperadminScreen extends StatelessWidget {
  const SuperadminScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Superadmin • Storico')),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: FirestoreService.matchesRef().orderBy('createdAt', descending: true).snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final matches = snapshot.data!.docs.map(MatchModel.fromDoc).toList();
          if (matches.isEmpty) {
            return const Center(child: Text('Nessuna partita.'));
          }
          return ListView.separated(
            itemCount: matches.length,
            separatorBuilder: (_, __) => const Divider(height: 1),
            itemBuilder: (context, i) {
              final m = matches[i];
              return ListTile(
                title: Text('${m.homeTeamAbbr} vs ${m.awayTeamAbbr}'),
                subtitle: Text('${m.matchDate.toLocal()} • ${m.venue} • ${m.status.name}'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => MatchDashboardScreen(match: m)),
                ),
              );
            },
          );
        },
      ),
    );
  }
}

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../models/match_model.dart';
import '../models/user_profile.dart';
import '../services/auth_service.dart';
import '../services/firestore_service.dart';
import 'match_setup_screen.dart';
import 'match_dashboard_screen.dart';
import 'superadmin/superadmin_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final user = AuthService.currentUser();
    return Scaffold(
      appBar: AppBar(
        title: const Text('Partite'),
        actions: [
          if (user != null)
            StreamBuilder(
              stream: FirestoreService.streamUserProfile(user.uid),
              builder: (context, snapshot) {
                final role = snapshot.hasData && snapshot.data!.exists
                    ? UserProfile.fromDoc(snapshot.data!).role
                    : UserRole.user;
                if (role != UserRole.superadmin) return const SizedBox.shrink();
                return IconButton(
                  icon: const Icon(Icons.admin_panel_settings),
                  tooltip: 'Superadmin',
                  onPressed: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => const SuperadminScreen()),
                    );
                  },
                );
              },
            ),
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () => AuthService.signOut(),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          Navigator.of(context).push(
            MaterialPageRoute(builder: (_) => const MatchSetupScreen()),
          );
        },
        icon: const Icon(Icons.add),
        label: const Text('Nuova partita'),
      ),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: FirestoreService.streamRecentMatches(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final docs = snapshot.data!.docs;
          if (docs.isEmpty) {
            return const Center(child: Text('Nessuna partita. Crea la prima.'));
          }
          final matches = docs.map(MatchModel.fromDoc).toList();
          return ListView.separated(
            itemCount: matches.length,
            separatorBuilder: (_, __) => const Divider(height: 1),
            itemBuilder: (context, i) {
              final m = matches[i];
              return ListTile(
                title: Text('${m.homeTeamAbbr} vs ${m.awayTeamAbbr}'),
                subtitle: Text('${m.matchDate.toLocal()} • ${m.venue} • ${m.status.name}'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => MatchDashboardScreen(match: m)),
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
}

import 'dart:async';

import 'package:flutter/material.dart';

import '../models/enums.dart';
import '../models/match_model.dart';
import '../models/registration_model.dart';
import '../models/user_profile.dart';
import '../services/auth_service.dart';
import '../services/export_service.dart';
import '../services/firestore_service.dart';
import '../services/match_clock_service.dart';
import 'registration_screen.dart';
import 'sections/discipline_screen.dart';
import 'sections/lineout_screen.dart';
import 'sections/possession_screen.dart';
import 'sections/scrum_screen.dart';
import 'sections/tackle_screen.dart';

class MatchDashboardScreen extends StatefulWidget {
  final MatchModel match;
  const MatchDashboardScreen({super.key, required this.match});

  @override
  State<MatchDashboardScreen> createState() => _MatchDashboardScreenState();
}

class _MatchDashboardScreenState extends State<MatchDashboardScreen> {
  late Timer _timer;
  int _clockSec = 0;

  UserRole _role = UserRole.user;
  RegistrationModel? _registration;
  bool _checkedAccess = false;

  MatchModel get match => widget.match;

  @override
  void initState() {
    super.initState();
    _loadAccess();
    _tick();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) => _tick());
  }

  Future<void> _loadAccess() async {
    final user = AuthService.currentUser();
    if (user == null) return;

    // role
    final profileSnap = await FirestoreService.usersRef().doc(user.uid).get();
    if (profileSnap.exists) {
      _role = UserProfile.fromDoc(profileSnap).role;
    }

    _registration = await FirestoreService.getRegistration(matchId: match.id, uid: user.uid);
    setState(() => _checkedAccess = true);

    if (!mounted) return;
    if (_role != UserRole.superadmin && (_registration == null || !_registration!.active)) {
      // Force registration flow
      final ok = await Navigator.of(context).push<bool>(
        MaterialPageRoute(
          builder: (_) => RegistrationScreen(
            matchId: match.id,
            expiresAt: match.expiresAt ?? DateTime.now().add(const Duration(minutes: 120)),
          ),
          fullscreenDialog: true,
        ),
      );
      if (ok == true) {
        _registration = await FirestoreService.getRegistration(matchId: match.id, uid: user.uid);
        if (mounted) setState(() {});
      }
    }
  }

  void _tick() {
    final start = match.startTime;
    if (start == null) return;
    setState(() {
      _clockSec = MatchClockService.elapsedSecondsSince(start);
    });
  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }

  Future<void> _export() async {
    final user = AuthService.currentUser();
    final file = await ExportService.exportMatchTagsAsJson(
      match: match,
      userId: user?.uid,
    );
    if (!mounted) return;
    await ExportService.shareFile(file);
  }

  Future<void> _endMatch() async {
    await FirestoreService.endMatch(match.id);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Partita terminata.')));
    Navigator.of(context).pop();
  }

  void _openSection(Widget screen) {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => screen));
  }

  bool _canAccess(MatchSection section) {
    if (_role == UserRole.superadmin) return true;
    final reg = _registration;
    if (reg == null || !reg.active) return false;
    if (DateTime.now().isAfter(reg.expiresAt)) return false;
    return reg.has(section);
  }

  @override
  Widget build(BuildContext context) {
    final clock = MatchClockService.formatClock(_clockSec);
    final disabledHint = !_checkedAccess ? null : 'Non registrato a questa sezione';

    return Scaffold(
      appBar: AppBar(
        title: Text('${match.homeTeamAbbr} vs ${match.awayTeamAbbr}'),
        actions: [
          PopupMenuButton<String>(
            onSelected: (v) async {
              if (v == 'export') {
                await _export();
              } else if (v == 'end') {
                await _endMatch();
              }
            },
            itemBuilder: (context) => const [
              PopupMenuItem(value: 'export', child: Text('Esporta file (tag)')),
              PopupMenuItem(value: 'end', child: Text('Fine partita')),
            ],
          )
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('${match.homeTeamFull} (CASA) vs ${match.awayTeamFull} (TRASFERTA)'),
                      const SizedBox(height: 4),
                      Text('${match.venue} • ${match.matchDate.toLocal()}'.split('.').first),
                    ],
                  ),
                  Column(
                    children: [
                      const Text('Tempo', style: TextStyle(fontWeight: FontWeight.bold)),
                      Text(clock, style: Theme.of(context).textTheme.headlineMedium),
                    ],
                  )
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          const Text('Sezioni', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          _SectionTile(
            title: 'Mischia',
            icon: Icons.groups,
            enabled: _canAccess(MatchSection.scrum),
            disabledHint: disabledHint,
            onTap: () => _openSection(ScrumScreen(match: match)),
          ),
          _SectionTile(
            title: 'Touche',
            icon: Icons.vertical_align_top,
            enabled: _canAccess(MatchSection.lineout),
            disabledHint: disabledHint,
            onTap: () => _openSection(LineoutScreen(match: match)),
          ),
          _SectionTile(
            title: 'Placcaggi',
            icon: Icons.shield,
            enabled: _canAccess(MatchSection.tackles),
            disabledHint: disabledHint,
            onTap: () => _openSection(TackleScreen(match: match)),
          ),
          _SectionTile(
            title: 'Disciplina',
            icon: Icons.gavel,
            enabled: _canAccess(MatchSection.discipline),
            disabledHint: disabledHint,
            onTap: () => _openSection(DisciplineScreen(match: match)),
          ),
          _SectionTile(
            title: 'Possesso',
            icon: Icons.timer,
            enabled: _canAccess(MatchSection.possession),
            disabledHint: disabledHint,
            onTap: () => _openSection(PossessionScreen(match: match)),
          ),
        ],
      ),
    );
  }
}

class _SectionTile extends StatelessWidget {
  final String title;
  final IconData icon;
  final VoidCallback onTap;
  final bool enabled;
  final String? disabledHint;
  const _SectionTile({
    required this.title,
    required this.icon,
    required this.onTap,
    this.enabled = true,
    this.disabledHint,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: Icon(icon),
        title: Text(title),
        trailing: const Icon(Icons.chevron_right),
        enabled: enabled,
        onTap: enabled
            ? onTap
            : () {
                final hint = disabledHint;
                if (hint != null) {
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(hint)));
                }
              },
      ),
    );
  }
}

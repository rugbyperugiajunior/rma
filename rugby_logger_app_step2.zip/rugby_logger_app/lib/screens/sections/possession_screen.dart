import 'package:flutter/material.dart';

import '../../models/enums.dart';
import '../../models/event_model.dart';
import '../../models/match_model.dart';
import '../../services/firestore_service.dart';
import '../../services/match_clock_service.dart';

class PossessionScreen extends StatefulWidget {
  final MatchModel match;
  const PossessionScreen({super.key, required this.match});

  @override
  State<PossessionScreen> createState() => _PossessionScreenState();
}

class _PossessionScreenState extends State<PossessionScreen> {
  TeamSide _team = TeamSide.home;
  PossessionStartReason _startReason = PossessionStartReason.recovery;
  PossessionEndReason _endReason = PossessionEndReason.turnover;

  bool _inProgress = false;
  int? _startClockSec;

  bool _loading = false;

  int _clock() => MatchClockService.elapsedSecondsSince(widget.match.startTime!);

  Future<void> _tapStart() async {
    if (widget.match.startTime == null) return;
    setState(() {
      _inProgress = true;
      _startClockSec = _clock();
    });
  }

  Future<void> _tapEnd() async {
    if (!_inProgress || _startClockSec == null) return;

    final endClockSec = _clock();
    final durationSec = (endClockSec - _startClockSec!).clamp(0, 1000000);

    // Dialog di conferma/modifica
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) {
        TeamSide team = _team;
        PossessionStartReason start = _startReason;
        PossessionEndReason end = _endReason;

        return AlertDialog(
          title: const Text('Conferma possesso'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              DropdownButtonFormField<TeamSide>(
                value: team,
                decoration: const InputDecoration(labelText: 'Squadra'),
                items: [
                  DropdownMenuItem(value: TeamSide.home, child: Text(widget.match.homeTeamAbbr)),
                  DropdownMenuItem(value: TeamSide.away, child: Text(widget.match.awayTeamAbbr)),
                ],
                onChanged: (v) => team = v ?? team,
              ),
              const SizedBox(height: 8),
              DropdownButtonFormField<PossessionStartReason>(
                value: start,
                decoration: const InputDecoration(labelText: 'Inizio possesso'),
                items: PossessionStartReason.values
                    .map((e) => DropdownMenuItem(value: e, child: Text(_startLabel(e))))
                    .toList(),
                onChanged: (v) => start = v ?? start,
              ),
              const SizedBox(height: 8),
              DropdownButtonFormField<PossessionEndReason>(
                value: end,
                decoration: const InputDecoration(labelText: 'Fine possesso'),
                items: PossessionEndReason.values
                    .map((e) => DropdownMenuItem(value: e, child: Text(_endLabel(e))))
                    .toList(),
                onChanged: (v) => end = v ?? end,
              ),
              const SizedBox(height: 12),
              Align(
                alignment: Alignment.centerLeft,
                child: Text('Durata: ${durationSec}s'),
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Annulla')),
            FilledButton(onPressed: () {
              // applica scelte al parent
              setState(() {
                _team = team;
                _startReason = start;
                _endReason = end;
              });
              Navigator.pop(context, true);
            }, child: const Text('Registra')),
          ],
        );
      },
    );

    if (ok != true) return;

    setState(() => _loading = true);
    try {
      final event = EventModel(
        id: '',
        type: EventType.possession,
        matchClockSec: endClockSec,
        createdAt: DateTime.now(),
        team: _team,
        payload: {
          'team': _team.name,
          'startReason': _startReason.name,
          'endReason': _endReason.name,
          'startClockSec': _startClockSec,
          'endClockSec': endClockSec,
          'durationSec': durationSec,
        },
      );

      await FirestoreService.addEvent(matchId: widget.match.id, event: event);

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Possesso registrato')));

      // pronto per nuovo evento
      setState(() {
        _inProgress = false;
        _startClockSec = null;
      });
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  static String _startLabel(PossessionStartReason r) {
    switch (r) {
      case PossessionStartReason.scrum:
        return 'Mischia';
      case PossessionStartReason.lineout:
        return 'Touche';
      case PossessionStartReason.recovery:
        return 'Recupero';
      case PossessionStartReason.penaltyKick:
        return 'Calcio Punizione';
      case PossessionStartReason.freeKick:
        return 'Calcio Libero';
      case PossessionStartReason.catchFromKick:
        return 'Presa da calcio';
    }
  }

  static String _endLabel(PossessionEndReason r) {
    switch (r) {
      case PossessionEndReason.scrum:
        return 'Mischia';
      case PossessionEndReason.lineout:
        return 'Touche';
      case PossessionEndReason.turnover:
        return 'Perdita possesso';
      case PossessionEndReason.penaltyKick:
        return 'Calcio Punizione';
      case PossessionEndReason.freeKick:
        return 'Calcio Libero';
      case PossessionEndReason.clearanceKick:
        return 'Calcio liberazione';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Possesso')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Squadra', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          SegmentedButton<TeamSide>(
            segments: [
              ButtonSegment(value: TeamSide.home, label: Text(widget.match.homeTeamAbbr)),
              ButtonSegment(value: TeamSide.away, label: Text(widget.match.awayTeamAbbr)),
            ],
            selected: {_team},
            onSelectionChanged: (s) => setState(() => _team = s.first),
          ),
          const SizedBox(height: 16),
          DropdownButtonFormField<PossessionStartReason>(
            value: _startReason,
            decoration: const InputDecoration(labelText: 'Inizio possesso'),
            items: PossessionStartReason.values
                .map((e) => DropdownMenuItem(value: e, child: Text(_startLabel(e))))
                .toList(),
            onChanged: (v) => setState(() => _startReason = v ?? _startReason),
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<PossessionEndReason>(
            value: _endReason,
            decoration: const InputDecoration(labelText: 'Fine possesso (pre-selezione, modificabile a conferma)'),
            items: PossessionEndReason.values
                .map((e) => DropdownMenuItem(value: e, child: Text(_endLabel(e))))
                .toList(),
            onChanged: (v) => setState(() => _endReason = v ?? _endReason),
          ),
          const SizedBox(height: 16),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(_inProgress ? 'Possesso IN CORSO' : 'Possesso NON attivo', style: const TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Text(_startClockSec == null ? '-' : 'Start: ${_startClockSec}s'),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: FilledButton(
                          onPressed: (_loading || _inProgress) ? null : _tapStart,
                          child: const Text('Inizio possesso'),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: FilledButton.tonal(
                          onPressed: (_loading || !_inProgress) ? null : _tapEnd,
                          child: const Text('Fine possesso'),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

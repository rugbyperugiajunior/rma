import 'package:flutter/material.dart';

import '../../models/enums.dart';
import '../../models/event_model.dart';
import '../../models/match_model.dart';
import '../../services/firestore_service.dart';
import '../../services/match_clock_service.dart';

class TackleScreen extends StatefulWidget {
  final MatchModel match;
  const TackleScreen({super.key, required this.match});

  @override
  State<TackleScreen> createState() => _TackleScreenState();
}

class _TackleScreenState extends State<TackleScreen> {
  TeamSide _team = TeamSide.home;
  TackleResult _result = TackleResult.good;
  bool _loading = false;

  int _clock() => MatchClockService.elapsedSecondsSince(widget.match.startTime!);

  Future<void> _save() async {
    if (widget.match.startTime == null) return;
    setState(() => _loading = true);
    try {
      final clock = _clock();
      final bucket5m = clock ~/ 300; // 0..n

      final event = EventModel(
        id: '',
        type: EventType.tackle,
        matchClockSec: clock,
        createdAt: DateTime.now(),
        team: _team,
        payload: {
          'team': _team.name,
          'result': _result.name,
          'bucket5m': bucket5m,
        },
      );

      await FirestoreService.addEvent(matchId: widget.match.id, event: event);

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Placcaggio registrato')));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Placcaggi')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Squadra', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          SegmentedButton<TeamSide>(
            segments: [
              ButtonSegment(value: TeamSide.home, label: Text(widget.match.homeTeamAbbr)),
              ButtonSegment(value: TeamSide.away, label: Text(widget.match.awayTeamAbbr)),
            ],
            selected: {_team},
            onSelectionChanged: (s) => setState(() => _team = s.first),
          ),
          const SizedBox(height: 16),
          const Text('Esito', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          SegmentedButton<TackleResult>(
            segments: const [
              ButtonSegment(value: TackleResult.good, label: Text('Corretto')),
              ButtonSegment(value: TackleResult.miss, label: Text('Sbagliato')),
            ],
            selected: {_result},
            onSelectionChanged: (s) => setState(() => _result = s.first),
          ),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: _loading ? null : _save,
              icon: const Icon(Icons.save),
              label: Text(_loading ? '...' : 'Registra evento'),
            ),
          ),
          const SizedBox(height: 12),
          const Text(
            'Nota: l\'aggregazione in finestre da 5 minuti avviene tramite il campo bucket5m = floor(clock/300).',
          ),
        ],
      ),
    );
  }
}

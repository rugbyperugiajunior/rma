import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../../models/enums.dart';
import '../../models/event_model.dart';
import '../../models/match_model.dart';
import '../../services/firestore_service.dart';
import '../../services/match_clock_service.dart';

class DisciplineScreen extends StatefulWidget {
  final MatchModel match;
  const DisciplineScreen({super.key, required this.match});

  @override
  State<DisciplineScreen> createState() => _DisciplineScreenState();
}

class _DisciplineScreenState extends State<DisciplineScreen> {
  TeamSide _team = TeamSide.home;
  FieldZone _zone = FieldZone.midfield;
  DisciplineSanction _sanction = DisciplineSanction.cp;
  DisciplineOrigin _origin = DisciplineOrigin.play;
  String? _foulTypeId;
  bool _loading = false;

  int _clock() => MatchClockService.elapsedSecondsSince(widget.match.startTime!);

  CollectionReference<Map<String, dynamic>> get _foulsRef => FirebaseFirestore.instance.collection('foulTypes');

  Future<void> _ensureDefaultsIfEmpty() async {
    final snap = await _foulsRef.limit(1).get();
    if (snap.docs.isNotEmpty) return;

    const defaults = [
      {'id': 'offside', 'label': 'Fuorigioco'},
      {'id': 'not_releasing', 'label': 'Tenuto'},
      {'id': 'side_entry', 'label': 'Entrata laterale'},
      {'id': 'hands_in_ruck', 'label': 'Mani in ruck'},
      {'id': 'high_tackle', 'label': 'Placcaggio alto'},
      {'id': 'obstruction', 'label': 'Ostruzione'},
      {'id': 'repeated', 'label': 'Falli ripetuti'},
      {'id': 'dissent', 'label': 'Proteste'},
      {'id': 'lineout_not_straight', 'label': 'Touche non dritta'},
      {'id': 'scrum_collapse', 'label': 'Collasso mischia'},
    ];

    final batch = FirebaseFirestore.instance.batch();
    for (final d in defaults) {
      final doc = _foulsRef.doc(d['id'] as String);
      batch.set(doc, {
        'label': d['label'],
        'active': true,
        'createdAt': FieldValue.serverTimestamp(),
      });
    }
    await batch.commit();
  }

  Future<void> _save() async {
    if (widget.match.startTime == null) return;
    if (_foulTypeId == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Seleziona il tipo di fallo')));
      return;
    }

    setState(() => _loading = true);
    try {
      final event = EventModel(
        id: '',
        type: EventType.discipline,
        matchClockSec: _clock(),
        createdAt: DateTime.now(),
        team: _team,
        payload: {
          'team': _team.name,
          'foulTypeId': _foulTypeId,
          'zone': _zone.name,
          'sanction': _sanction.name,
          'origin': _origin.name,
        },
      );

      await FirestoreService.addEvent(matchId: widget.match.id, event: event);

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Fallo registrato')));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  void initState() {
    super.initState();
    // crea la lista base falli solo se non esiste (MVP)
    _ensureDefaultsIfEmpty();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Disciplina')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Squadra', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          SegmentedButton<TeamSide>(
            segments: [
              ButtonSegment(value: TeamSide.home, label: Text(widget.match.homeTeamAbbr)),
              ButtonSegment(value: TeamSide.away, label: Text(widget.match.awayTeamAbbr)),
            ],
            selected: {_team},
            onSelectionChanged: (s) => setState(() => _team = s.first),
          ),
          const SizedBox(height: 16),
          StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
            stream: _foulsRef.where('active', isEqualTo: true).snapshots(),
            builder: (context, snap) {
              final docs = snap.data?.docs ?? [];
              final items = docs
                  .map((d) => DropdownMenuItem<String>(value: d.id, child: Text(d.data()['label'] as String)))
                  .toList();

              return DropdownButtonFormField<String>(
                value: _foulTypeId,
                decoration: const InputDecoration(labelText: 'Tipologia di fallo'),
                items: items,
                onChanged: (v) => setState(() => _foulTypeId = v),
              );
            },
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<FieldZone>(
            value: _zone,
            decoration: const InputDecoration(labelText: 'Zona di campo'),
            items: FieldZone.values.map((z) => DropdownMenuItem(value: z, child: Text(z.label))).toList(),
            onChanged: (v) => setState(() => _zone = v ?? FieldZone.midfield),
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<DisciplineSanction>(
            value: _sanction,
            decoration: const InputDecoration(labelText: 'Sanzione'),
            items: const [
              DropdownMenuItem(value: DisciplineSanction.cp, child: Text('Calcio piazzato (CP)')),
              DropdownMenuItem(value: DisciplineSanction.cl, child: Text('Calcio libero (CL)')),
            ],
            onChanged: (v) => setState(() => _sanction = v ?? DisciplineSanction.cp),
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<DisciplineOrigin>(
            value: _origin,
            decoration: const InputDecoration(labelText: 'Origine (da gioco/mischia/touche)'),
            items: const [
              DropdownMenuItem(value: DisciplineOrigin.play, child: Text('Da gioco')),
              DropdownMenuItem(value: DisciplineOrigin.scrum, child: Text('Da mischia')),
              DropdownMenuItem(value: DisciplineOrigin.lineout, child: Text('Da touche')),
            ],
            onChanged: (v) => setState(() => _origin = v ?? DisciplineOrigin.play),
          ),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: _loading ? null : _save,
              icon: const Icon(Icons.save),
              label: Text(_loading ? '...' : 'Registra evento'),
            ),
          ),
          const SizedBox(height: 12),
          const Text(
            'Lista falli modificabile: collezione Firestore `foulTypes` (campi: label, active).\n'
            'Nel MVP la lista viene creata automaticamente se non esiste.',
          ),
        ],
      ),
    );
  }
}

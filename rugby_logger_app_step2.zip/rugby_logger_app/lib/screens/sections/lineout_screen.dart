import 'package:flutter/material.dart';

import '../../models/enums.dart';
import '../../models/event_model.dart';
import '../../models/match_model.dart';
import '../../services/firestore_service.dart';
import '../../services/match_clock_service.dart';

class LineoutScreen extends StatefulWidget {
  final MatchModel match;
  const LineoutScreen({super.key, required this.match});

  @override
  State<LineoutScreen> createState() => _LineoutScreenState();
}

class _LineoutScreenState extends State<LineoutScreen> {
  TeamSide? _thrownBy;
  TeamSide? _wonBy;
  int _block = 1;
  FieldZone _zone = FieldZone.midfield;
  bool _loading = false;

  int _clock() => MatchClockService.elapsedSecondsSince(widget.match.startTime!);

  Future<void> _save() async {
    if (widget.match.startTime == null) return;
    if (_thrownBy == null || _wonBy == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Compila tutti i campi.')));
      return;
    }

    setState(() => _loading = true);
    try {
      final event = EventModel(
        id: '',
        type: EventType.lineout,
        matchClockSec: _clock(),
        createdAt: DateTime.now(),
        payload: {
          'thrownBy': _thrownBy!.name,
          'wonBy': _wonBy!.name,
          'block': _block,
          'zone': _zone.name,
        },
      );

      await FirestoreService.addEvent(matchId: widget.match.id, event: event);

      setState(() {
        _thrownBy = null;
        _wonBy = null;
        _block = 1;
        _zone = FieldZone.midfield;
      });

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Touche registrata')));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Touche')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _TeamChoice(
            title: 'Lancio',
            homeLabel: widget.match.homeTeamAbbr,
            awayLabel: widget.match.awayTeamAbbr,
            value: _thrownBy,
            onChanged: (v) => setState(() => _thrownBy = v),
          ),
          const SizedBox(height: 12),
          _TeamChoice(
            title: 'Vinta da',
            homeLabel: widget.match.homeTeamAbbr,
            awayLabel: widget.match.awayTeamAbbr,
            value: _wonBy,
            onChanged: (v) => setState(() => _wonBy = v),
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<int>(
            value: _block,
            decoration: const InputDecoration(labelText: 'Blocco salto'),
            items: const [
              DropdownMenuItem(value: 1, child: Text('Blocco 1')),
              DropdownMenuItem(value: 2, child: Text('Blocco 2')),
              DropdownMenuItem(value: 3, child: Text('Blocco 3')),
            ],
            onChanged: (v) => setState(() => _block = v ?? 1),
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<FieldZone>(
            value: _zone,
            decoration: const InputDecoration(labelText: 'Zona di campo'),
            items: FieldZone.values.map((z) => DropdownMenuItem(value: z, child: Text(z.label))).toList(),
            onChanged: (v) => setState(() => _zone = v ?? FieldZone.midfield),
          ),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: _loading ? null : _save,
              icon: const Icon(Icons.save),
              label: Text(_loading ? '...' : 'Registra evento'),
            ),
          ),
        ],
      ),
    );
  }
}

class _TeamChoice extends StatelessWidget {
  final String title;
  final String homeLabel;
  final String awayLabel;
  final TeamSide? value;
  final ValueChanged<TeamSide> onChanged;

  const _TeamChoice({
    required this.title,
    required this.homeLabel,
    required this.awayLabel,
    required this.value,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        SegmentedButton<TeamSide>(
          segments: [
            ButtonSegment(value: TeamSide.home, label: Text(homeLabel)),
            ButtonSegment(value: TeamSide.away, label: Text(awayLabel)),
          ],
          selected: value == null ? <TeamSide>{} : <TeamSide>{value!},
          onSelectionChanged: (set) {
            if (set.isNotEmpty) onChanged(set.first);
          },
        ),
      ],
    );
  }
}

import 'dart:async';

import 'package:flutter/material.dart';

import '../models/registration_model.dart';
import '../services/auth_service.dart';
import '../services/firestore_service.dart';
import '../services/iap_service.dart';

/// Registration screen: select sections, calculate cost (1€ per section),
/// and persist a registration doc under:
/// `matches/{matchId}/registrations/{userId}`.
///
/// IMPORTANT:
/// - This screen includes an IAP scaffold. Real purchases require store setup.
/// - For MVP testing you can enable "Debug: simula acquisto".
class RegistrationScreen extends StatefulWidget {
  final String matchId;
  final DateTime expiresAt;

  const RegistrationScreen({
    super.key,
    required this.matchId,
    required this.expiresAt,
  });

  @override
  State<RegistrationScreen> createState() => _RegistrationScreenState();
}

class _RegistrationScreenState extends State<RegistrationScreen> {
  final Map<MatchSection, bool> _sel = {
    for (final s in MatchSection.values) s: false,
  };

  bool _debugSimulatePurchase = true;
  bool _busy = false;
  StreamSubscription? _sub;

  int get _sectionCount => _sel.values.where((v) => v).length;
  double get _costEuro => _sectionCount * 1.0;

  @override
  void initState() {
    super.initState();
    _sub = IapService.purchaseStream().listen((purchases) async {
      // For this starter we just complete purchases.
      for (final p in purchases) {
        await IapService.completeIfNeeded(p);
      }
    });
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  Future<void> _confirm() async {
    final user = AuthService.currentUser();
    if (user == null) return;
    if (_sectionCount == 0) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Seleziona almeno una sezione.')));
      return;
    }

    setState(() => _busy = true);
    try {
      // MVP: persist registration immediately.
      // In production you should only write this after a successful IAP + server validation.
      final selected = _sel.entries.where((e) => e.value).map((e) => e.key).toList();
      final reg = RegistrationModel(
        userId: user.uid,
        sections: selected,
        expiresAt: widget.expiresAt,
        active: true,
        purchaseToken: _debugSimulatePurchase ? 'DEBUG_SIMULATED' : null,
      );
      await FirestoreService.upsertRegistration(matchId: widget.matchId, registration: reg);

      if (!_debugSimulatePurchase) {
        // IAP scaffold: in a real app you'd map each section to a product id and purchase each.
        // See: https://pub.dev/packages/in_app_purchase
      }

      if (mounted) {
        Navigator.of(context).pop(true);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Errore registrazione: $e')));
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  String _label(MatchSection s) {
    switch (s) {
      case MatchSection.scrum:
        return 'Mischia';
      case MatchSection.lineout:
        return 'Touche';
      case MatchSection.tackles:
        return 'Placcaggi';
      case MatchSection.discipline:
        return 'Disciplina';
      case MatchSection.possession:
        return 'Possesso';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Registrazione partita')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Seleziona le sezioni a cui vuoi accedere (1€ ciascuna):'),
            const SizedBox(height: 12),
            ...MatchSection.values.map(
              (s) => SwitchListTile(
                title: Text(_label(s)),
                value: _sel[s]!,
                onChanged: _busy ? null : (v) => setState(() => _sel[s] = v),
              ),
            ),
            const Divider(),
            Row(
              children: [
                Expanded(child: Text('Totale: €${_costEuro.toStringAsFixed(2)}')),
                const SizedBox(width: 12),
                FilledButton.icon(
                  onPressed: _busy ? null : _confirm,
                  icon: _busy
                      ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.check),
                  label: const Text('Conferma'),
                ),
              ],
            ),
            const SizedBox(height: 12),
            SwitchListTile(
              title: const Text('Debug: simula acquisto (consigliato per test)') ,
              value: _debugSimulatePurchase,
              onChanged: _busy ? null : (v) => setState(() => _debugSimulatePurchase = v),
            ),
            const Text(
              'Nota: per attivare i pagamenti reali serve configurare i prodotti in Google Play / App Store.',
              style: TextStyle(fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }
}

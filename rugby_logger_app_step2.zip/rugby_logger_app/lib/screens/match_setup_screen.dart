import 'package:flutter/material.dart';
import '../models/enums.dart';
import '../models/match_model.dart';
import '../services/firestore_service.dart';
import 'match_dashboard_screen.dart';

class MatchSetupScreen extends StatefulWidget {
  const MatchSetupScreen({super.key});

  @override
  State<MatchSetupScreen> createState() => _MatchSetupScreenState();
}

class _MatchSetupScreenState extends State<MatchSetupScreen> {
  final _homeFull = TextEditingController();
  final _awayFull = TextEditingController();
  final _homeAbbr = TextEditingController();
  final _awayAbbr = TextEditingController();
  final _venue = TextEditingController();

  DateTime _date = DateTime.now();
  int _gameDuration = 80;
  bool _loading = false;
  String? _error;

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
      initialDate: _date,
    );
    if (picked != null) setState(() => _date = picked);
  }

  Future<void> _createAndStart() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final match = MatchModel(
        id: 'TEMP',
        homeTeamFull: _homeFull.text.trim(),
        awayTeamFull: _awayFull.text.trim(),
        homeTeamAbbr: _homeAbbr.text.trim().toUpperCase(),
        awayTeamAbbr: _awayAbbr.text.trim().toUpperCase(),
        matchDate: _date,
        venue: _venue.text.trim(),
        status: MatchStatus.draft,
        gameDurationMinutes: _gameDuration,
      );

      final matchId = await FirestoreService.createMatch(match);
      final startTime = DateTime.now();
      final expiresAt = startTime.add(const Duration(minutes: 120));
      await FirestoreService.setMatchLive(matchId: matchId, startTime: startTime, expiresAt: expiresAt);

      final liveMatch = MatchModel(
        id: matchId,
        homeTeamFull: match.homeTeamFull,
        awayTeamFull: match.awayTeamFull,
        homeTeamAbbr: match.homeTeamAbbr,
        awayTeamAbbr: match.awayTeamAbbr,
        matchDate: match.matchDate,
        venue: match.venue,
        status: MatchStatus.live,
        gameDurationMinutes: match.gameDurationMinutes,
        startTime: startTime,
        expiresAt: expiresAt,
      );

      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => MatchDashboardScreen(match: liveMatch)),
      );
    } catch (e) {
      setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  void dispose() {
    _homeFull.dispose();
    _awayFull.dispose();
    _homeAbbr.dispose();
    _awayAbbr.dispose();
    _venue.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Setup partita')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Squadre', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          TextField(controller: _homeFull, decoration: const InputDecoration(labelText: 'Squadra CASA (nome esteso)')),
          TextField(controller: _awayFull, decoration: const InputDecoration(labelText: 'Squadra TRASFERTA (nome esteso)')),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _homeAbbr,
                  maxLength: 3,
                  decoration: const InputDecoration(labelText: 'CASA (3 lettere)', counterText: ''),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: TextField(
                  controller: _awayAbbr,
                  maxLength: 3,
                  decoration: const InputDecoration(labelText: 'TRASFERTA (3 lettere)', counterText: ''),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          const Text('Partita', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          ListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Giorno partita'),
            subtitle: Text('${_date.toLocal()}'.split(' ').first),
            trailing: const Icon(Icons.calendar_month),
            onTap: _pickDate,
          ),
          TextField(controller: _venue, decoration: const InputDecoration(labelText: 'Campo di gioco')),
          const SizedBox(height: 16),
          DropdownButtonFormField<int>(
            value: _gameDuration,
            decoration: const InputDecoration(labelText: 'Tempo di gioco (minuti)'),
            items: const [
              DropdownMenuItem(value: 80, child: Text('80 (2x40)')),
              DropdownMenuItem(value: 70, child: Text('70 (2x35)')),
              DropdownMenuItem(value: 60, child: Text('60 (2x30)')),
            ],
            onChanged: (v) => setState(() => _gameDuration = v ?? 80),
          ),
          const SizedBox(height: 16),
          if (_error != null) Text(_error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: _loading ? null : _createAndStart,
              icon: const Icon(Icons.play_arrow),
              label: Text(_loading ? '...' : 'Inizia partita'),
            ),
          ),
        ],
      ),
    );
  }
}

import * as admin from 'firebase-admin';
import * as functions from 'firebase-functions/v2';

admin.initializeApp();

/**
 * Scadenza automatica: imposta status=EXPIRED quando now > expiresAt.
 * Suggerimento: schedula ogni 1-5 minuti.
 */
export const expireMatchIfNeeded = functions.scheduler.onSchedule(
  { schedule: 'every 5 minutes' },
  async () => {
    const db = admin.firestore();
    const now = admin.firestore.Timestamp.now();

    const snap = await db
      .collection('matches')
      .where('status', '==', 'live')
      .where('expiresAt', '<=', now)
      .get();

    const batch = db.batch();
    snap.docs.forEach((doc) => {
      batch.update(doc.ref, { status: 'expired', endTime: now });
    });
    await batch.commit();
  }
);

/**
 * Trigger fine partita: qui puoi generare statistiche e inviarle per utente (filtrate per sezione registrata).
 * Nel MVP lasciamo solo un placeholder.
 */
export const onMatchEndedGenerateReports = functions.firestore.onDocumentUpdated(
  'matches/{matchId}',
  async (event) => {
    const before = event.data?.before.data();
    const after = event.data?.after.data();
    if (!before || !after) return;

    const beforeStatus = before.status;
    const afterStatus = after.status;

    if (beforeStatus === 'live' && (afterStatus === 'ended' || afterStatus === 'expired')) {
      // TODO:
      // 1) leggi eventi
      // 2) calcola stats/indici per sezione e squadra
      // 3) per ogni registrazione utente: filtra sezioni e invia report (email/push)
      console.log('Match ended -> generate reports', event.params.matchId);
    }
  }
);

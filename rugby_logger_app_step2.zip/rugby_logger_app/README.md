# Rugby Logger (Flutter + Firebase)

App Android/iOS per registrare eventi di una partita di rugby (Mischia, Touche, Placcaggi, Disciplina, Possesso), calcolare statistiche/indici e generare un **file unico** (JSON) con le principali tag delle sezioni.

> Questo pacchetto è uno **starter/MVP**: include UI e modelli dati pronti, regole Firestore di base e Cloud Functions (stub) per scadenza partita e generazione report.

## Stack
- Flutter
- Firebase: Auth, Firestore, Functions
- path_provider + share_plus (export file)

## Setup Firebase
1. Crea un progetto su Firebase.
2. Abilita **Authentication** (Email/Password).
3. Crea **Firestore** (Native mode).
4. (Opzionale) Abilita **Cloud Functions**.

### Configura FlutterFire
Da root progetto:
```bash
flutter pub get
flutterfire configure
```
Questo genera `lib/firebase_options.dart` (non incluso qui).

## Firestore: collezioni
- `users/{uid}`: `{ displayName, role: 'USER'|'SUPERADMIN' }`
- `matches/{matchId}`: metadati partita + `status` + `startTime` + `expiresAt`
- `matches/{matchId}/events/{eventId}`: eventi (type + payload)
- `matches/{matchId}/registrations/{uid}`: sezioni acquistate/abilitate + scadenza

## Time/Clock
- Conteggio **continuo**: `matchClock = now - startTime`.
- Nessuna pausa/stop nel MVP (puoi aggiungerla in seguito).

## Export file unico (JSON)
Dalla schermata partita → menu (⋮) → **Esporta file**.
- Il file contiene `match` + `tags` per sezione:
  - mischie (introducedBy, wonBy, driveBy, zone)
  - touche (thrownBy, wonBy, block, zone)
  - placcaggi (team, result, bucket5m)
  - disciplina (team, foulTypeId, zone, sanction, origin)
  - possesso (team, startReason, endReason, durationSec)

Il file viene salvato nella directory documenti dell'app e condivisibile tramite Share Sheet.

## Sicurezza
Vedi `firestore/firestore.rules`.
- blocco scrittura eventi se partita non LIVE o se scaduta
- superadmin può leggere tutto

## Cloud Functions (stub)
`functions/src/index.ts` contiene:
- `expireMatchIfNeeded` (schedulata)
- `onMatchEndedGenerateReports` (trigger)

## Avvio
```bash
flutter run
```

## Roadmap (consigliata)
- Pagamenti IAP (Apple/Google) e verifica server-side
- Pannello superadmin per storico partite
- Statistiche avanzate e indici
- Export anche CSV/PDF
